---
name: Aurelian Minimalist
colors:
  surface: '#fbf9f8'
  surface-dim: '#dbdad9'
  surface-bright: '#fbf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3f3'
  surface-container: '#efeded'
  surface-container-high: '#e9e8e7'
  surface-container-highest: '#e4e2e2'
  on-surface: '#1b1c1c'
  on-surface-variant: '#444748'
  inverse-surface: '#303031'
  inverse-on-surface: '#f2f0f0'
  outline: '#747878'
  outline-variant: '#c4c7c7'
  surface-tint: '#5f5e5e'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1c1b1b'
  on-primary-container: '#858383'
  inverse-primary: '#c8c6c5'
  secondary: '#775a19'
  on-secondary: '#ffffff'
  secondary-container: '#fed488'
  on-secondary-container: '#785a1a'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#1a1c1b'
  on-tertiary-container: '#838482'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e5e2e1'
  primary-fixed-dim: '#c8c6c5'
  on-primary-fixed: '#1c1b1b'
  on-primary-fixed-variant: '#474646'
  secondary-fixed: '#ffdea5'
  secondary-fixed-dim: '#e9c176'
  on-secondary-fixed: '#261900'
  on-secondary-fixed-variant: '#5d4201'
  tertiary-fixed: '#e3e2e0'
  tertiary-fixed-dim: '#c7c6c5'
  on-tertiary-fixed: '#1a1c1b'
  on-tertiary-fixed-variant: '#464746'
  background: '#fbf9f8'
  on-background: '#1b1c1c'
  surface-variant: '#e4e2e2'
  deep-charcoal: '#121212'
  soft-gold: '#C5A059'
  pale-gold: '#E2D1B0'
  linen-white: '#F9F8F6'
  pure-white: '#FFFFFF'
  slate-gray: '#4A4A4A'
typography:
  display-lg:
    fontFamily: EB Garamond
    fontSize: 64px
    fontWeight: '400'
    lineHeight: 72px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: EB Garamond
    fontSize: 40px
    fontWeight: '400'
    lineHeight: 48px
  headline-lg-mobile:
    fontFamily: EB Garamond
    fontSize: 32px
    fontWeight: '400'
    lineHeight: 40px
  headline-md:
    fontFamily: EB Garamond
    fontSize: 28px
    fontWeight: '400'
    lineHeight: 36px
  title-lg:
    fontFamily: Hanken Grotesk
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
    letterSpacing: 0.05em
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 30px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  label-caps:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.15em
  button:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.1em
spacing:
  unit: 4px
  container-max: 1440px
  gutter: 24px
  margin-desktop: 80px
  margin-mobile: 20px
  stack-lg: 64px
  stack-md: 32px
  stack-sm: 16px
---

## Brand & Style

This design system embodies the "Quiet Luxury" aesthetic—a philosophy where quality and restraint take precedence over loud branding. Designed for a high-end jewelry e-commerce platform, the visual language is sophisticated, intentional, and exclusive.

The primary style is **Minimalism with a Tactile Luxury finish**. It relies on generous whitespace (macro-spacing) to allow product photography to breathe, creating a gallery-like experience. Subtle "ghost" borders and refined hairline strokes replace heavy shadows to define structure. The user should feel a sense of calm, prestige, and trust, evoking the emotional response of entering a private boutique.

- **Focus:** High-end craftsmanship, editorial layouts, and frictionless elegance.
- **Visual Signature:** Refined hairlines (0.5px to 1px), centered typography, and a "less is more" approach to UI elements.

## Colors

The palette is rooted in a monochromatic foundation with metallic accents to denote value and interaction.

- **Primary (Deep Charcoal):** Used for primary text, iconography, and high-impact structural elements. It provides the "weight" in the design.
- **Secondary (Soft Gold):** Reserved for call-to-actions, price points, and active states. It should be used sparingly as a "jewelry" piece for the UI itself.
- **Tertiary (Linen White):** A soft, warm off-white used for section backgrounds to reduce eye strain and provide a more premium feel than pure white.
- **Neutral:** Mid-tones used for secondary labels and hairline borders.

Color application should follow a 60-30-10 distribution: 60% Whites/Linens, 30% Charcoal/Dark text, and 10% Gold accents.

## Typography

The typographic scale relies on the contrast between the timeless, literary quality of **EB Garamond** and the modern, architectural precision of **Hanken Grotesk**.

- **Headlines:** Use EB Garamond for all editorial headers and product names. This creates an authoritative and heritage-focused atmosphere.
- **Body & Navigation:** Use Hanken Grotesk for readability and a modern edge. 
- **Utility & Labels:** Small labels and buttons should utilize Hanken Grotesk in Uppercase with increased letter spacing to evoke the look of luxury engravings.
- **Alignment:** Prefer centered alignment for hero headers and product titles to maintain a boutique-catalog feel.

## Layout & Spacing

The layout philosophy is based on a **Fixed Grid** with exaggerated margins to enforce the luxury aesthetic.

- **Grid:** A 12-column grid for desktop with 24px gutters. Use 4-column offsets for centered content to create focal points.
- **Rhythm:** Utilize a base 4px unit, but prioritize large "Stack" increments (64px+) between sections to ensure the interface never feels crowded.
- **Mobile:** Transition to a 2-column or 1-column grid. Margins should reduce to 20px, but vertical padding between products should remain high to maintain the premium feel.
- **Photography:** All product images should use a consistent aspect ratio (1:1 or 4:5) with centered subjects and generous internal padding.

## Elevation & Depth

This design system avoids traditional heavy shadows in favor of **Tonal Layers** and **Refined Outlines**.

- **Depth:** Surfaces are defined by color shifts (e.g., Linen White vs. Pure White) rather than drop shadows.
- **Borders:** Use 1px solid borders in `#E2D1B0` (Pale Gold) or a light gray for cards and input fields. This creates "contained elegance" without the bulk of shadows.
- **Overlays:** For modals and drawers, use a subtle backdrop blur (glassmorphism) with a 20% opacity Charcoal tint to maintain context while focusing the user.
- **Active State:** Instead of lifting an element, use a subtle color shift or a thin gold inner-border to indicate selection.

## Shapes

The shape language is **Sharp (0px)**. 

Luxury is often defined by precision and architectural lines. This design system rejects the "bubbliness" of common web apps. Every button, card, and input field should have crisp, 90-degree corners. This creates a more formal, high-fashion appearance consistent with jewelry boxes and high-end store displays. 

*Note: The only exceptions are circular elements like color swatches or profile avatars, which should remain perfect circles.*

## Components

- **Buttons:** Primary buttons are solid Deep Charcoal with white Hanken Grotesk text in all-caps. Secondary buttons use a transparent background with a 1px Gold border. Hover states should involve a subtle background fill of Soft Gold or a slight darkening of the Charcoal.
- **Input Fields:** Minimalist design with only a bottom-border (1px) in light gray. When focused, the border transitions to Soft Gold. Labels sit above the field in `label-caps`.
- **Cards:** Product cards are borderless with the product image taking priority. Titles and prices are centered underneath. A subtle 1px border may appear on hover.
- **Chips/Filters:** Rectangular with 0px radius. Active filters are Charcoal with White text; inactive filters use a hairline border.
- **Lists:** Clean, high-contrast rows with generous vertical padding (24px+). Use the primary Gold color for small accents like bullet points or "In Stock" indicators.
- **Checkboxes/Radios:** Custom-styled as small squares (0px radius) that fill with Gold when selected, maintaining the architectural theme.